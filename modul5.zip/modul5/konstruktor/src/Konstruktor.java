/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author LAB-RPL
 */
public class Konstruktor {
    String nama = "Rulla";
    String NIM = "L202173005";
    String alamat = "Sragen";
    Konstruktor(){
        System.out.println(nama);
        System.out.println(NIM);
        System.out.println(alamat);
    }
}
