/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LAB-RPL
 */
public class Buku {
   String namaPengarang, judulBuku;
   int tahunTerbit, cetakanKe;
   double hargaJual;
   
   Buku(String pengarang, String judul, int tahun, int cetakan, double harga){
      this.namaPengarang = pengarang;
      this.judulBuku = judul;
      this.tahunTerbit = tahun;
      this.cetakanKe = cetakan;
      this.hargaJual = harga;
   }
   public void infoBuku(){
       System.out.println(
                "Nama pengarang : "+namaPengarang+"\n"+
                "Judul buku : "+judulBuku+"\n"+
                "Tahun terbit : "+tahunTerbit+"\n"+
                "Cetakan ke : "+cetakanKe+"\n"+
                "Harga : "+hargaJual+"\n");
   }
}
