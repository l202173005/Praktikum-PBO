
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LAB-RPL
 */
public class Akseskonstruktor {
    public static void main(String[] args) throws ParseException {
        Konstruktor panggil = new Konstruktor();
        
        System.out.println("\n");
        
        Buku buku1 = new Buku("hhh", "hyuu", 2018, 1, 100.000);
        Buku buku2 = new Buku("park", "jiunniee sii", 2018, 1, 100.000);
        Buku buku3 = new Buku("woojin", "kauuuuuu kuu", 2018, 1, 100.000);
        Buku buku4 = new Buku("parkku", "jinja", 2018, 1, 100.000);
        Buku buku5 = new Buku("jihoon", "gwanchana", 2018, 1, 100.000);
        Buku buku6 = new Buku("Ryu", "hey you", 2018, 1, 100.000);
        Buku buku7 = new Buku("alina", "guanlinnnn", 2018, 1, 100.000);
        Buku buku8 = new Buku("jinyoung", "daehwinnnya", 2018, 1, 100.000);
        Buku buku9 = new Buku("bae bae", "kukukaka", 2018, 1, 100.000);
        Buku buku10 = new Buku("danie", "DUDUDUDU", 2018, 1, 100.000);      
        
        buku1.infoBuku();
        buku2.infoBuku();
        buku3.infoBuku();
        buku4.infoBuku();
        buku5.infoBuku();
        buku6.infoBuku();
        buku7.infoBuku();
        buku8.infoBuku();
        buku9.infoBuku();
        buku10.infoBuku();
        
        OverLoadingCons over1 = new OverLoadingCons();
        OverLoadingCons over2 = new OverLoadingCons(108, "Rulla");
        OverLoadingCons over3 = new OverLoadingCons(124, new Date());
        OverLoadingCons over4 = new OverLoadingCons(108, "Rulla", 124);
        OverLoadingCons over5 = new OverLoadingCons(108, "Rulla", 124, new Date());
        
        CustomerData cd1 = new CustomerData("Rulla","Sragen", new SimpleDateFormat("dd/mm/yyyy").parse("16/06/1999"),"Mahasiswi", 10000);
        CustomerData cd2 = new CustomerData("Rulla","Sragen", new SimpleDateFormat("dd/mm/yyyy").parse("16/06/1999"),"Mahasiswi", 100000);
        CustomerData cd3 = new CustomerData("Rulla","Sragen", new SimpleDateFormat("dd/mm/yyyy").parse("16/06/1999"),"Mahasiswi", 100000);
        CustomerData cd4 = new CustomerData("Rulla","Sragen", new SimpleDateFormat("dd/mm/yyyy").parse("16/06/1999"),"Mahasiswi", 100000);
        CustomerData cd5 = new CustomerData("Rulla","Sragen", new SimpleDateFormat("dd/mm/yyyy").parse("16/06/1999"),"Mahasiswi", 100000);
        CustomerData cd6 = new CustomerData("Rulla","Sragen", new SimpleDateFormat("dd/mm/yyyy").parse("16/06/1999"),"Mahasiswi", 100000);
        CustomerData cd7 = new CustomerData("Rulla","Sragen", new SimpleDateFormat("dd/mm/yyyy").parse("16/06/1999"),"Mahasiswi", 100000);
        CustomerData cd8 = new CustomerData("Rulla","Sragen", new SimpleDateFormat("dd/mm/yyyy").parse("16/06/1999"),"Mahasiswi", 100000);
        CustomerData cd9 = new CustomerData("Rulla","Sragen", new SimpleDateFormat("dd/mm/yyyy").parse("16/06/1999"),"Mahasiswi", 100000);
        CustomerData cd10 = new CustomerData("Rulla","Sragen", new SimpleDateFormat("dd/mm/yyyy").parse("16/06/1999"),"Mahasiswi", 100000);
        









    }
}
