/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Date;
/**
 *
 * @author LAB-RPL
 */
public class OverLoadingCons {
int idUser;
String userName;
int level;
Date lastLogin;
public OverLoadingCons(){
}
public OverLoadingCons(int iduser, String userName){
    this.idUser = iduser;
    this.userName = userName;
    System.out.println(
            "ID User : "+this.idUser+"\n"+
            "Username : "+this.userName+"\n");
}

public OverLoadingCons(int level, Date lastLogin){
    this.level = level;
    this.lastLogin = lastLogin;
    System.out.println(
            "Level : "+this.level+"\n"+
            "Last Login : "+this.lastLogin+"\n");
}

public OverLoadingCons(int iduser, String userName, int level){
    this.idUser = iduser;
    this.userName = userName;
    this.level = level;
    System.out.println(
            "ID User : "+this.idUser+"\n"+
            "Username : "+this.userName+"\n"+
            "Level : "+this.level+"\n");
}

public OverLoadingCons(int iduser, String userName, int level, Date lastLogin){
    this.idUser = iduser;
    this.userName = userName;
    this.level = level;
    this.lastLogin = lastLogin;
    System.out.println(
            "ID User : "+this.idUser+"\n"+
            "Username : "+this.userName+"\n"+
            "Level : "+this.level+"\n"+
            "Last Login : "+this.lastLogin+"\n");
}
}
