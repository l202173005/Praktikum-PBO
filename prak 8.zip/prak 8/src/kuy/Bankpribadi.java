/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuy;

/**
 *
 * @author rulla
 */
public class Bankpribadi extends Bank {
    public int rasioBunga(){
        return 10;
    }
    public static void main(String[] args) {
        Bank bp = new Bankpribadi();
        bp.rasioBunga();
        System.out.println("Rasio Bunga Bank Pribadi");
        System.out.println("Rasio Bunga : "+bp.rasioBunga()+"%");
    }
}
