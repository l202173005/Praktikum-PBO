/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PBO;
import kuy.Bank;

/**
 * 
 * @author rulla
 */

public class Bankumum extends Bank{
    @Override
    public int rasioBunga(){
        return 20;
    }
}
