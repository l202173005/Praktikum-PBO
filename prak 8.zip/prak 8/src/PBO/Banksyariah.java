/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PBO;

/**
 * 
 * @author rulla
 */
public class Banksyariah extends Bankumum{
    public int rasioBunga(){
        return 25;
    }
    public static void main(String[] args) {
        Bankumum bs = new Banksyariah();
        bs.rasioBunga();
        System.out.println("Rasio Bunga Bank Pasar Adalah");
        System.out.println("Rasio Bunganya : "+bs.rasioBunga()+"%");
        System.out.println("=====================================");
        Bankumum bpasar = new Bankpasar();
        System.out.println("Rasio Bunga Bank Pasar Adalah");
        System.out.println("Rasio Bunganya : "+bpasar.rasioBunga()+"%");
    }
}
