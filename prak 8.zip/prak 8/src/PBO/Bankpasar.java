/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PBO;

/**
 * 
 * @author rulla
 */
public class Bankpasar extends Bankumum{
    @Override
    public int rasioBunga(){
        return 15;
    }
    public static void main(String[] args) {
        Bankumum bpas = new Bankpasar();
        bpas.rasioBunga();
        System.out.println("Rasio Bunga Bank Pasar Adalah");
        System.out.println("Rasio Bunganya : "+bpas.rasioBunga()+"%");
        System.out.println("============================");
        Bankumum bu = new Bankumum();
        bpas.rasioBunga();
        System.out.println("Rasio Bunga Bank PasarAdalah");
        System.out.println("Rasio Bunganya : "+bu.rasioBunga()+"%");
    }
}

