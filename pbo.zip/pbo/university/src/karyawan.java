/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class karyawan {
    String nama;
    String alamat;
    String jabatan;
    double gaji;
    
    void tampilkanNama(){
        nama = "Chamsae";
        System.out.println("Nama Karyawan : "+nama);
    }
    
    void tampilkanAlamat(){
        alamat = "Gwangju, seoul";
        System.out.println("Alamat Karyawan : "+alamat);
    }
    
    void tampilkanJabatan(){
        jabatan = "Manager Of Schollogy";
        System.out.println("Jabatan Karyawan : "+jabatan);
    }
    
    void tampilkanGaji(){
        gaji = 80000;
        System.out.println("Gaji Karyawan : Rp."+gaji);
    }
}
