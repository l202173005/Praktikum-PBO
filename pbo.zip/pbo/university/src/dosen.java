/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class dosen {
    String nama;
    String pendidikan;
    String ttl;
    int nik;
    
    void tampilkanNama(){
        nama = "Bunsodan";
        System.out.println("Nama Dosen : "+nama);
    }
    
    void tampilkanNik (){
        nik = 999;
        System.out.println("NIK Dosen : "+nik);
    }
    
    void tampilkanPendidikan(){
        pendidikan = "Prof";
        System.out.println("Pendidikan Dosen : "+pendidikan);
    }
    
    void tampilkanTglLahir(){
        ttl = "12 September 1990";
        System.out.println("Tanggal lahir Dosen : "+ttl);
    }
}
