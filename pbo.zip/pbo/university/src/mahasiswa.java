public class mahasiswa {
    String nama;
    String nim;
    String alamat;
    int semester;
    
    void tampilkanNama(){
        nama = "Rulla Selfiana";
        System.out.println("Nama Mahasiswa : "+nama);
    }
    
    void tampilkanNim(){
        nim = "L202173005";
        System.out.println("NIM Mahasiswa : "+nim);
    }
    
    void tampilkanAlamat(){
        alamat = "Karangnongko Karangmalang Masaran Sragen";
        System.out.println("Alamat Mahasiswa : "+alamat);
    }
    
    void tampilkanSemester(){
        semester = 3;
        System.out.println("Semester Mahasiswa : "+semester);
    }
}
