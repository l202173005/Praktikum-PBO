/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
import java.util.Scanner;

public class kalimat {
    
void bacaHuruf(){
        String huruf;
        Scanner input1 = new Scanner(System.in);
        System.out.println("Tuliskan kalimat : ");
        huruf = input1.nextLine();
        System.out.println("Jumlah huruf yang didapat : " + huruf.length());
    }
    public static void main(String[] args) {
        kalimat baca = new kalimat();
        baca.bacaHuruf();
    }
     
     
}
